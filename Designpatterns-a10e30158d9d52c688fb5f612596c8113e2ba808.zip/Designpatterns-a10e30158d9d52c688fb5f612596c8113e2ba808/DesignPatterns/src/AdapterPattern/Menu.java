package AdapterPattern;

public interface Menu {
    public void getPizza();
    public String getPizzaToppings();
}
